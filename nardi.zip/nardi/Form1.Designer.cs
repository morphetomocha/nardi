﻿
namespace nardi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shahid = new System.Windows.Forms.TextBox();
            this.knigga = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.suboba = new System.Windows.Forms.TextBox();
            this.papich = new System.Windows.Forms.TextBox();
            this.amogus = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.kazahstan = new System.Windows.Forms.TextBox();
            this.bombardirovka = new System.Windows.Forms.TextBox();
            this.tiKtoPoMasti = new System.Windows.Forms.TextBox();
            this.aPoSushestvu = new System.Windows.Forms.TextBox();
            this.tiLoh = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // shahid
            // 
            this.shahid.Location = new System.Drawing.Point(12, 13);
            this.shahid.Name = "shahid";
            this.shahid.Size = new System.Drawing.Size(100, 23);
            this.shahid.TabIndex = 0;
            // 
            // knigga
            // 
            this.knigga.Location = new System.Drawing.Point(12, 42);
            this.knigga.Name = "knigga";
            this.knigga.Size = new System.Drawing.Size(100, 23);
            this.knigga.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 71);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 39);
            this.button1.TabIndex = 2;
            this.button1.Text = "Туда его";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // suboba
            // 
            this.suboba.Location = new System.Drawing.Point(11, 116);
            this.suboba.Name = "suboba";
            this.suboba.Size = new System.Drawing.Size(101, 23);
            this.suboba.TabIndex = 3;
            // 
            // papich
            // 
            this.papich.Location = new System.Drawing.Point(132, 17);
            this.papich.Name = "papich";
            this.papich.Size = new System.Drawing.Size(100, 23);
            this.papich.TabIndex = 4;
            // 
            // amogus
            // 
            this.amogus.Location = new System.Drawing.Point(132, 46);
            this.amogus.Name = "amogus";
            this.amogus.Size = new System.Drawing.Size(100, 23);
            this.amogus.TabIndex = 5;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(132, 104);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 45);
            this.button2.TabIndex = 6;
            this.button2.Text = "Добить выживших";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // kazahstan
            // 
            this.kazahstan.Location = new System.Drawing.Point(132, 75);
            this.kazahstan.Name = "kazahstan";
            this.kazahstan.Size = new System.Drawing.Size(100, 23);
            this.kazahstan.TabIndex = 7;
            // 
            // bombardirovka
            // 
            this.bombardirovka.Location = new System.Drawing.Point(132, 155);
            this.bombardirovka.Name = "bombardirovka";
            this.bombardirovka.Size = new System.Drawing.Size(100, 23);
            this.bombardirovka.TabIndex = 8;
            // 
            // textBox1
            // 
            this.tiKtoPoMasti.Location = new System.Drawing.Point(301, 17);
            this.tiKtoPoMasti.Name = "textBox1";
            this.tiKtoPoMasti.Size = new System.Drawing.Size(100, 23);
            this.tiKtoPoMasti.TabIndex = 9;
            // 
            // textBox2
            // 
            this.aPoSushestvu.Location = new System.Drawing.Point(301, 46);
            this.aPoSushestvu.Name = "textBox2";
            this.aPoSushestvu.Size = new System.Drawing.Size(105, 23);
            this.aPoSushestvu.TabIndex = 10;
            // 
            // textBox3
            // 
            this.tiLoh.Location = new System.Drawing.Point(301, 116);
            this.tiLoh.Name = "textBox3";
            this.tiLoh.Size = new System.Drawing.Size(100, 23);
            this.tiLoh.TabIndex = 11;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(301, 78);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 24);
            this.button3.TabIndex = 12;
            this.button3.Text = "Блэкджэк";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tiLoh);
            this.Controls.Add(this.aPoSushestvu);
            this.Controls.Add(this.tiKtoPoMasti);
            this.Controls.Add(this.bombardirovka);
            this.Controls.Add(this.kazahstan);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.amogus);
            this.Controls.Add(this.papich);
            this.Controls.Add(this.suboba);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.knigga);
            this.Controls.Add(this.shahid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox shahid;
        private System.Windows.Forms.TextBox knigga;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox suboba;
        private System.Windows.Forms.TextBox papich;
        private System.Windows.Forms.TextBox amogus;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox kazahstan;
        private System.Windows.Forms.TextBox bombardirovka;
        private System.Windows.Forms.TextBox tiKtoPoMasti;
        private System.Windows.Forms.TextBox aPoSushestvu;
        private System.Windows.Forms.TextBox tiLoh;
        private System.Windows.Forms.Button button3;
    }
}

